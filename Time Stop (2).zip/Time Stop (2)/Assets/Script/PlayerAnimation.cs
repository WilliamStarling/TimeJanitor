﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimation : MonoBehaviour
{
    PlayerController playerController;
    Animator animator;
    void Start()
    {
        playerController = Object.FindObjectOfType<PlayerController>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey("a") || Input.GetKey("d") || Input.GetKey("left") || Input.GetKey("right") && playerController.isGrounded == true){
            animator.Play("Running");
 //           Debug.Log("yes");
        }else if(playerController.isGrounded == false){
            animator.Play("falling");
        }else{
            animator.Play("idle");
        }
    }
}
