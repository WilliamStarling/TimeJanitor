﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuLoader : MonoBehaviour
{
    //config params
    public GameObject menu;
    public GameObject backstory;
    public GameObject levelList;
    GameObject current;
    // variables
   public bool isBackstory = false;
   public bool isLevelList = false;
    public bool isMainMenu = false;

    private void Start()
    {
        menu.gameObject.SetActive(true);
        current = menu;
        backstory.gameObject.SetActive(false);
        levelList.gameObject.SetActive(false); 
    }
    private void Update()
    {
    }
    public void QuitGame()
    {
        Application.Quit();
    }

}
