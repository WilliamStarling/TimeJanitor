﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //Config Param
    PlayerMovement playerMovement;
    SceneLoader sceneLoader;
    BreakableObstacle breakableObstacle;

    //variables
    bool canMakeJumpTrue = false;
    public bool isGrounded = false;
    public bool canClimbR = false;
    public bool canClimbL = false;
    public bool isCrashed = false;
    public bool canHit = false;

    private void Start()
    {
        playerMovement = Object.FindObjectOfType<PlayerMovement>();
        sceneLoader = Object.FindObjectOfType<SceneLoader>();
        breakableObstacle = Object.FindObjectOfType<BreakableObstacle>();
    }
    private void OnTriggerStay2D(Collider2D collisionInfo)
    {
        if (canMakeJumpTrue == true)
        {
            playerMovement.canJump = true;
            canMakeJumpTrue = false;
        }
        if (collisionInfo.CompareTag("Ground"))
        {
            isGrounded = true;
        }
        if (collisionInfo.CompareTag("Enemy"))
        {
            sceneLoader.ReloadScene();
        }
        if (collisionInfo.CompareTag("Wall"))
        {
            if (collisionInfo.transform.position.x > gameObject.transform.position.x)
            {
                canClimbR = true;
            }
            else if (collisionInfo.transform.position.x < gameObject.transform.position.x)
            {
                canClimbL = true;
            }
        }
        isCrashed = true;
    }
    private void OnTriggerExit2D(Collider2D collisionInfo)
    {
        if (collisionInfo.CompareTag("Ground"))
        {
            isGrounded = false;
        }
        if (collisionInfo.CompareTag("Wall"))
        {
            canClimbR = false;
            canClimbL = false;
            playerMovement.canMove = true;
        }
        canMakeJumpTrue = true;
        isCrashed = false;
    }
}
