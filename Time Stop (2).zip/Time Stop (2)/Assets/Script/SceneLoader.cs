﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    public GameObject pauseMenu;
    bool isPaused = false;
    private void Update()
    {
        if(isPaused == false && Input.GetButtonDown("Pause"))
        {
            pauseMenu.gameObject.SetActive(true);
            Time.timeScale = 0;
            isPaused = true;
        }
        else if(isPaused == true && Input.GetButtonDown("Pause"))
        {
            pauseMenu.gameObject.SetActive(false);
            Time.timeScale = 1;
            isPaused = false;
        }

    }

    public void LoadNextScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void ReloadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void LoadFirstScene()
    {
        SceneManager.LoadScene(0);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
    public void Unpause()
    {
        pauseMenu.gameObject.SetActive(false);
        Time.timeScale = 1;
        isPaused = false;
    }
}
