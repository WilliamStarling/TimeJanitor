﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu (menuName = "Dialog")]
public class DialogScript : ScriptableObject
{
    [TextArea(5, 7)] public string dialogLines;
    public DialogScript nextLine;
    public string ReturnDialog()
    {
        return dialogLines;
    }
    
    public DialogScript ReturnNextLine()
    {
        return nextLine;
    }
}
