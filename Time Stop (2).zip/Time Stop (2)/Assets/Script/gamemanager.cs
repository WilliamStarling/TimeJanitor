﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gamemanager : MonoBehaviour
{
    //i was using this then i realized its actually not useful so u can use it now :DDDDD
}
