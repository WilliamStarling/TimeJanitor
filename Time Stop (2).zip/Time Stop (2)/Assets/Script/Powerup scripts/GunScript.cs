﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunScript : MonoBehaviour
{
    //can use powerup variables
    public bool canShoot;
    //cosmetics
    public GameObject gun;
    private void OnTriggerEnter2D(Collider2D collisionInfo)
    {
        if (collisionInfo.CompareTag("Player"))
        {
            canShoot = true;
            gun.gameObject.SetActive(true);
            Destroy(gameObject);
        }
    }
}