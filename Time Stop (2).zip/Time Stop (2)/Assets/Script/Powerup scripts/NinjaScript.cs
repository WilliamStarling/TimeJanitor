﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NinjaScript : MonoBehaviour
{
    //can use powerup variables
    public bool isNinja;
    //cosmetics
    public GameObject ninjaMask;
    private void OnTriggerEnter2D(Collider2D collisionInfo)
    {
        if (collisionInfo.CompareTag("Player"))
        {
            isNinja = true;
            ninjaMask.gameObject.SetActive(true);
            Destroy(gameObject);
        }
    }
}