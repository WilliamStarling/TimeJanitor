﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GliderScript : MonoBehaviour
{
    //can use powerup variables
    public bool canGlide;
    //cosmetics
    public GameObject glider;
    private void OnTriggerEnter2D(Collider2D collisionInfo)
    {
        if (collisionInfo.CompareTag("Player"))
        {
            canGlide = true;
            Destroy(gameObject);
        }
    }
}