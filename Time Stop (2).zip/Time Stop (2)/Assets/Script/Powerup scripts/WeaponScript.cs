﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponScript : MonoBehaviour
{
    public Transform shootPoint;
    GunScript gunScript;
    public GameObject bulletParticles;

    private void Start()
    {
        gunScript = Object.FindObjectOfType<GunScript>();
    }
    // Update is called once per frame
    void Update()
    {
        if (gunScript.canShoot == true && Input.GetKeyDown(KeyCode.Z))
        {
            Fire();
        }
    }

    void Fire()
    {
        Instantiate(bulletParticles, shootPoint);
        RaycastHit2D hitInfo = Physics2D.Raycast(shootPoint.position, shootPoint.right);
        Enemy enemy = hitInfo.transform.GetComponent<Enemy>();
        if(enemy != null)
        {
            enemy.wasHit();
        }
    }
}
