﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BreakableObstacle : MonoBehaviour
{
    //config params
    HammerScript hammerScript;
    PlayerController playerController;
    public Sprite hitSprite;

    //Variables
    int currentHL = 2;
    bool canHit;

    // Start is called before the first frame update
    void Start()
    {
        hammerScript = Object.FindObjectOfType<HammerScript>();
        playerController = Object.FindObjectOfType<PlayerController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (canHit == true && hammerScript.hammerTime == true && Input.GetKeyDown(KeyCode.X))
        {
            currentHL--;
            if (currentHL <= 0)
            {
                Destroy(gameObject);
            }
            else
            {
                gameObject.GetComponent<SpriteRenderer>().sprite = hitSprite;
            }
        }
    }
    private void OnCollisionStay2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            canHit = true;
        }
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            canHit = false;
        }
    }
}
