﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HammerScript : MonoBehaviour
{
    //can use powerup variables
    public bool hammerTime;
    //cosmetics
    public GameObject hammer;
    private void OnTriggerEnter2D(Collider2D collisionInfo)
    {
        if (collisionInfo.CompareTag("Player"))
        {
            hammerTime = true;
            hammer.gameObject.SetActive(true);
            Destroy(gameObject);
        }
    }
}