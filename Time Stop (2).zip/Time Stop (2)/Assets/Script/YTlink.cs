﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YTlink : MonoBehaviour
{
    public void OpenLink(){
        Application.OpenURL("https://www.youtube.com/channel/UCCLw6kJDw8g2eDd2oAFQ66g?view_as=subscriber");
    }
}
