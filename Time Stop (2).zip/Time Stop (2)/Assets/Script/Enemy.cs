﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] float speed = 3f;
    [SerializeField] float lookradius = 2.5f;
    float timer = 2f;
    float maxTimer = 2f;
    float Otimer = 2f;
    [SerializeField] float respawnTime = 2f;
    int rng;
    bool IsPlayerNear;
    bool Isgroundleft;
    Transform Target;
    Vector3 spawnPoint;
    SpriteRenderer spriteRenderer;
    Collider2D boxCollider2d;
    Rigidbody2D rigid;
    private LayerMask layermask;
    public int health = 3;
    private void Start() {
        //finds the correct references
        Target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        boxCollider2d = GetComponent<BoxCollider2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigid = GetComponent<Rigidbody2D>();
        layermask = LayerMask.GetMask("Surfaces");
        //sets up its spawnPoint
        spawnPoint = transform.position;
        IsGrounded();
    }
    private void Update() {
        //moves enemy toward player if it is a certain distance
        if(IsGrounded() == true && IsPlayerNear == true){
            transform.position = Vector2.MoveTowards(transform.position,Target.position,speed * Time.deltaTime);
        }else if(IsGrounded() == true && IsPlayerNear == false){
            //exicutes the Patrol Mode unless the player is near
            PatrolMode();
        }else if(IsGrounded() == false && Isgroundleft == true){
            transform.position += Vector3.left * speed * Time.deltaTime;
        }else if(IsGrounded() == false && Isgroundleft == false){
            transform.position += Vector3.right * speed * Time.deltaTime;
        }
        //ditermines if the player is in the activation zone
        float distance = Vector3.Distance(Target.position, transform.position);
        if(distance <= lookradius){
            IsPlayerNear = true;
        }else{
            IsPlayerNear = false;
        }
        //randomly generates a random number every second and takes a pos
        timer -= Time.deltaTime;
        if(timer <= 0){
            rng = Random.Range(1,4);
            timer = maxTimer;
        }
        if(transform.position.y < -20f){
            Otimer -= Time.deltaTime;
            if(Otimer <= 0){
            transform.position = spawnPoint;
            rigid.velocity = Vector2.zero;
            Otimer = respawnTime;
            }
        }
    }
    private bool IsGrounded(){
        //creates a raycast that checks if the enemy is grounded
        float extrahight = .7f;
        RaycastHit2D hit = Physics2D.Raycast(boxCollider2d.bounds.center,Vector2.down,boxCollider2d.bounds.extents.y + extrahight, layermask);
        Color rayColor;
        if(hit.collider != null){
            rayColor = Color.green;
        }else{
            rayColor = Color.red;
        }
        Debug.DrawRay(boxCollider2d.bounds.center, Vector2.down * (boxCollider2d.bounds.extents.y + extrahight));
        return hit.collider != null;
    }
    private void PatrolMode(){
        //creates a mode in which the enemy will randomly move
        if(rng == 1 && IsGrounded() == true){
            transform.position += Vector3.left * speed * Time.deltaTime;
            spriteRenderer.flipX = true;
        }

        if(rng == 2 && IsGrounded() == true){
            transform.position += Vector3.right * speed * Time.deltaTime;
            spriteRenderer.flipX = false;
        }
        
        if(IsGrounded() == false){
            Debug.Log("falling");
        }
    }
    private void OnDrawGizmosSelected() {
        //creates a sphere to simulate the activation distance
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, lookradius);
    }

    public void wasHit()
    {
        health -= 1;
        if(health <= 0)
        {
            Destroy(gameObject);
        }
        if(Target.position.x < transform.position.x)
        {
            rigid.AddForce(new Vector2(5f, 0f), ForceMode2D.Impulse);
        }
        else if (Target.position.x > transform.position.x)
        {
            rigid.AddForce(new Vector2(-5f, 0f), ForceMode2D.Impulse);
        }
    }
    private void OnTriggerStay2D(Collider2D other) {
        if(other.gameObject.tag == "Ground"){
            Isgroundleft = true;
        }else{
            Isgroundleft = false;
        }
    }
    private void OnTriggerExit2D(Collider2D other) {
        Isgroundleft = false;
    }
}
