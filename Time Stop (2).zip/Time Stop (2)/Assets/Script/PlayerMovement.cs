﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    //Configuration Paramaters
    [SerializeField] float speed = 5f;
    public float sideMove = 0f;
    public float jumpHeight = 5f;
    public float xJumpLSize = -3f;
    public float xJumpRSize = 3f;
    public float yJumpSize = 7f;


    //Setups
    PlayerController playerController;
    NinjaScript ninjaScript;
    GliderScript gliderScript;
    Rigidbody2D rigidBody;
    SceneLoader sceneLoader;

    //variables
    public bool canMove = true;
    public bool canJump = true;
    public float glideX = 2.5f;
    public float glideY = 1f;
    bool isGliding = false;
    float glideDirection;
    bool canStop;
    bool isRight = true;
    bool isStuck;

    private void Start()
    {
        playerController = Object.FindObjectOfType<PlayerController>();
        ninjaScript = Object.FindObjectOfType<NinjaScript>();
        gliderScript = Object.FindObjectOfType<GliderScript>();
        rigidBody = gameObject.GetComponent<Rigidbody2D>();
        sceneLoader = Object.FindObjectOfType<SceneLoader>();
    }

    void Update()
    {
        sideMove = Input.GetAxis("Horizontal");
        if(playerController.isGrounded == true){
            canMove = true;
        }
        flipIt();
        IsDead();
    }

    private void FixedUpdate()
    {
        MoveSideways();
        Jump();
        NinjaStick();
        Gliding();
    }
    public void Jump()
    {
        if(Input.GetButton("Jump") && canJump == true && playerController.isGrounded == true && canMove == true)
        {
            canJump = false;
            rigidBody.AddForce(new Vector2(0f, jumpHeight), ForceMode2D.Impulse);
            playerController.isGrounded = false;
        }
    }

    public void MoveSideways()
    {
        if (canMove == true)
        {
            Vector3 SideMove = new Vector3(sideMove, 0f, 0f);
            transform.position += SideMove * Time.deltaTime * speed;
        }
    }
    
    void flipIt()
    {
        if (canMove == true)
        {
            if (sideMove < 0 && isRight == true || sideMove > 0 && isRight == false)
            {
                isRight = !isRight;
                transform.Rotate(0f, 180f, 0f);
            }
        }

    }

    private void NinjaStick()
    {
        if (ninjaScript.isNinja == true && playerController.isGrounded == false)
        {
            if (playerController.canClimbR == true)
            {
                isStuck = true;
                canMove = false;
                rigidBody.constraints = RigidbodyConstraints2D.FreezeAll;
                if (Input.GetButton("Jump"))
                {
                    rigidBody.constraints = RigidbodyConstraints2D.None;
                    rigidBody.constraints = RigidbodyConstraints2D.FreezeRotation;
                    rigidBody.AddForce(new Vector2(xJumpLSize, yJumpSize), ForceMode2D.Impulse);
                    isStuck = false;
                }
            }
            else if (playerController.canClimbL == true)
            {
                isStuck = true;
                canMove = false;
                rigidBody.constraints = RigidbodyConstraints2D.FreezeAll;
                if (Input.GetButtonDown("Jump"))
                {
                    rigidBody.constraints = RigidbodyConstraints2D.None;
                    rigidBody.constraints = RigidbodyConstraints2D.FreezeRotation;
                    rigidBody.AddForce(new Vector2(xJumpRSize, yJumpSize), ForceMode2D.Impulse);
                    isStuck = false;
                }
            }
        }
    }
    private void IsDead()
    {
        if(transform.position.y < -10)
        {
            sceneLoader.ReloadScene();
        }
    }

    private void Gliding()
    {
        if(gliderScript.canGlide == true && isStuck == false)
        {
            if (Input.GetKey(KeyCode.C) && playerController.isGrounded == false)
            {
                isGliding = true;
            }
            if(playerController.isCrashed == true)
            {
                if(canStop == true)
                {
                    rigidBody.velocity = new Vector2(0f, 0f);
                    canStop = false;
                }
                isGliding = false;
                gliderScript.glider.SetActive(false);
                canMove = true;
                if (isRight == true){
                    glideDirection = 1;
                }else if(isRight == false){
                    glideDirection = -1;
                }
            }
            if(isGliding == true)
            {
                canMove = false;
                canStop = true;
                rigidBody.velocity = new Vector2(glideX * glideDirection, glideY);
                gliderScript.glider.gameObject.SetActive(true);
            }
        }
    }
}
