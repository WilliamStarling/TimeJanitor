﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextManager : MonoBehaviour
{
    //config params
    public Text dialogBox;
    public DialogScript testDialog;
    public Animator animator;
    public GameObject dialogBackground;
    DialogScript dialogScript;

    //variables 
    bool canRead = false;

    // Start is called before the first frame update
    void Start()
    {
        dialogScript = testDialog;
        dialogBox.text = dialogScript.ReturnDialog();
        animator.SetBool("entering", false);
        animator.SetBool("leaving", false);

    }

    // Update is called once per frame
    void Update()
    {
        CallNextState();
    }

    private void CallNextState()
    {
        var nextState = dialogScript.ReturnNextLine();
        if(canRead == true && Input.GetKeyDown(KeyCode.Return))
        {
            dialogScript = nextState;
        }
        dialogBox.text = dialogScript.ReturnDialog();
    }
    public void AnimationOver()
    {
        animator.SetBool("entranceOver", true);
    }

    public void OnTriggerEnter2D(Collider2D collisionInfo)
    {
        if (collisionInfo.CompareTag("Player"))
        {

            animator.SetBool("entering", true);
            animator.SetBool("leaving", false);
            canRead = true;
        }
    }
   public void OnTriggerExit2D(Collider2D collisionInfo)
    {
        if (collisionInfo.CompareTag("Player"))
        {

            animator.SetBool("leaving", true);
            animator.SetBool("entering", false);
            canRead = false;
        }
    }
}
